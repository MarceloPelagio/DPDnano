`timescale 1ns/1ps

/******************************************************************************
* HW006 - Input Memory Protocol
*
* Request frame: 9 bytes
*   [0] 0xA5
*   [1] command
*   [2] address high
*   [3] address low
*   [4] data[31:24]
*   [5] data[23:16]
*   [6] data[15:8]
*   [7] data[7:0]
*   [8] checksum = XOR bytes 0..7
*
* Response frame: 9 bytes
*   [0] 0x5A
*   [1] command
*   [2] address high
*   [3] address low
*   [4] data/status[31:24]
*   [5] data/status[23:16]
*   [6] data/status[15:8]
*   [7] data/status[7:0]
*   [8] checksum = XOR bytes 0..7
*
* Commands:
*   0x01 PING
*   0x02 VERSION
*   0x20 WRITE MEMORY
*   0x21 READ MEMORY
*
* Valid addresses:
*   0x0000 to 0x00FF
*
* Errors:
*   0x000000E1 unknown command
*   0x000000E2 checksum error
*   0x000000E3 invalid address
******************************************************************************/

module protocol_hw006 (
    input  wire       clk,
    input  wire       rst_n,

    input  wire [7:0] rx_data_i,
    input  wire       rx_valid_i,
    input  wire       rx_frame_error_i,

    input  wire       tx_busy_i,
    output reg  [7:0] tx_data_o,
    output reg        tx_start_o,

    output reg        busy_o,
    output wire       done_o,
    output wire       error_o
);

localparam [7:0] SOF_REQ = 8'hA5;
localparam [7:0] SOF_RSP = 8'h5A;

localparam [7:0] CMD_PING    = 8'h01;
localparam [7:0] CMD_VERSION = 8'h02;
localparam [7:0] CMD_WRITE   = 8'h20;
localparam [7:0] CMD_READ    = 8'h21;

localparam [31:0] ERR_UNKNOWN = 32'h000000E1;
localparam [31:0] ERR_CSUM    = 32'h000000E2;
localparam [31:0] ERR_ADDR    = 32'h000000E3;

localparam [3:0]
    ST_WAIT_SOF = 4'd0,
    ST_GET_CMD  = 4'd1,
    ST_GET_AH   = 4'd2,
    ST_GET_AL   = 4'd3,
    ST_GET_D3   = 4'd4,
    ST_GET_D2   = 4'd5,
    ST_GET_D1   = 4'd6,
    ST_GET_D0   = 4'd7,
    ST_GET_CSUM = 4'd8,
    ST_SEND     = 4'd9;

reg [3:0] state;

reg [7:0] cmd_reg;
reg [7:0] addr_hi_reg;
reg [7:0] addr_lo_reg;
reg [31:0] data_reg;

(* syn_ramstyle = "block_ram" *)
reg [31:0] input_memory [0:255];

reg [7:0] response [0:8];
reg [3:0] tx_index;

reg [24:0] done_count;
reg error_latched;

integer i;

wire [15:0] address = {addr_hi_reg, addr_lo_reg};

wire [7:0] request_checksum =
    SOF_REQ ^
    cmd_reg ^
    addr_hi_reg ^
    addr_lo_reg ^
    data_reg[31:24] ^
    data_reg[23:16] ^
    data_reg[15:8] ^
    data_reg[7:0];

assign done_o  = (done_count != 0);
assign error_o = error_latched;

task build_response;
    input [7:0] command;
    input [15:0] response_address;
    input [31:0] response_data;
    begin
        response[0] <= SOF_RSP;
        response[1] <= command;
        response[2] <= response_address[15:8];
        response[3] <= response_address[7:0];
        response[4] <= response_data[31:24];
        response[5] <= response_data[23:16];
        response[6] <= response_data[15:8];
        response[7] <= response_data[7:0];
        response[8] <=
            SOF_RSP ^
            command ^
            response_address[15:8] ^
            response_address[7:0] ^
            response_data[31:24] ^
            response_data[23:16] ^
            response_data[15:8] ^
            response_data[7:0];
    end
endtask

always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
        state         <= ST_WAIT_SOF;
        cmd_reg       <= 8'h00;
        addr_hi_reg   <= 8'h00;
        addr_lo_reg   <= 8'h00;
        data_reg      <= 32'h00000000;
        tx_data_o     <= 8'h00;
        tx_start_o    <= 1'b0;
        tx_index      <= 4'd0;
        busy_o        <= 1'b0;
        done_count    <= 25'd0;
        error_latched <= 1'b0;

        for (i = 0; i < 256; i = i + 1)
            input_memory[i] <= 32'h00000000;
    end else begin
        tx_start_o <= 1'b0;

        if (done_count != 0)
            done_count <= done_count - 1'b1;

        if (rx_frame_error_i)
            error_latched <= 1'b1;

        case (state)
            ST_WAIT_SOF: begin
                busy_o <= 1'b0;

                if (rx_valid_i && rx_data_i == SOF_REQ) begin
                    busy_o <= 1'b1;
                    state  <= ST_GET_CMD;
                end
            end

            ST_GET_CMD: begin
                if (rx_valid_i) begin
                    cmd_reg <= rx_data_i;
                    state   <= ST_GET_AH;
                end
            end

            ST_GET_AH: begin
                if (rx_valid_i) begin
                    addr_hi_reg <= rx_data_i;
                    state       <= ST_GET_AL;
                end
            end

            ST_GET_AL: begin
                if (rx_valid_i) begin
                    addr_lo_reg <= rx_data_i;
                    state       <= ST_GET_D3;
                end
            end

            ST_GET_D3: begin
                if (rx_valid_i) begin
                    data_reg[31:24] <= rx_data_i;
                    state           <= ST_GET_D2;
                end
            end

            ST_GET_D2: begin
                if (rx_valid_i) begin
                    data_reg[23:16] <= rx_data_i;
                    state           <= ST_GET_D1;
                end
            end

            ST_GET_D1: begin
                if (rx_valid_i) begin
                    data_reg[15:8] <= rx_data_i;
                    state          <= ST_GET_D0;
                end
            end

            ST_GET_D0: begin
                if (rx_valid_i) begin
                    data_reg[7:0] <= rx_data_i;
                    state         <= ST_GET_CSUM;
                end
            end

            ST_GET_CSUM: begin
                if (rx_valid_i) begin
                    if (rx_data_i != request_checksum) begin
                        build_response(cmd_reg, address, ERR_CSUM);
                        error_latched <= 1'b1;
                    end
                    else begin
                        case (cmd_reg)
                            CMD_PING: begin
                                build_response(
                                    CMD_PING,
                                    address,
                                    32'h00000000
                                );
                            end

                            CMD_VERSION: begin
                                build_response(
                                    CMD_VERSION,
                                    address,
                                    32'h00000302
                                );
                            end

                            CMD_WRITE: begin
                                if (address < 16'd256) begin
                                    input_memory[address[7:0]] <= data_reg;
                                    build_response(
                                        CMD_WRITE,
                                        address,
                                        32'h00000000
                                    );
                                end
                                else begin
                                    build_response(
                                        CMD_WRITE,
                                        address,
                                        ERR_ADDR
                                    );
                                    error_latched <= 1'b1;
                                end
                            end

                            CMD_READ: begin
                                if (address < 16'd256) begin
                                    build_response(
                                        CMD_READ,
                                        address,
                                        input_memory[address[7:0]]
                                    );
                                end
                                else begin
                                    build_response(
                                        CMD_READ,
                                        address,
                                        ERR_ADDR
                                    );
                                    error_latched <= 1'b1;
                                end
                            end

                            default: begin
                                build_response(
                                    cmd_reg,
                                    address,
                                    ERR_UNKNOWN
                                );
                                error_latched <= 1'b1;
                            end
                        endcase
                    end

                    tx_index <= 4'd0;
                    state    <= ST_SEND;
                end
            end

            ST_SEND: begin
                if (!tx_busy_i && !tx_start_o) begin
                    tx_data_o  <= response[tx_index];
                    tx_start_o <= 1'b1;

                    if (tx_index == 4'd8) begin
                        tx_index   <= 4'd0;
                        busy_o     <= 1'b0;
                        done_count <= 25'd8100000;
                        state      <= ST_WAIT_SOF;
                    end
                    else begin
                        tx_index <= tx_index + 1'b1;
                    end
                end
            end

            default: state <= ST_WAIT_SOF;
        endcase
    end
end

endmodule

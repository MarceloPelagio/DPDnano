DPDnano_Lite_v3_2 - HW006 Input Memory
========================================

OBJETIVO
--------
Validar escrita e leitura de uma memória de entrada com:

- 256 posições;
- 32 bits por posição;
- endereço de 16 bits no protocolo;
- dados compatíveis com I/Q:

  bits 31..16 = I
  bits 15..0  = Q

LOCAL DOS ARQUIVOS
------------------
Coloque todos os arquivos deste pacote em:

src\dpdnano_hw_top

REUTILIZAR
----------
Não copie novamente os módulos UART se eles já estiverem no projeto:

uart_rx_27m_115200.v
uart_tx_27m_115200.v

Mantenha apenas uma cópia de cada módulo no projeto Gowin.

TOP MODULE
----------
dpdnano_hw006_input_memory_top

PROTOCOLO
---------
Requisição de 9 bytes:

A5 CMD AH AL D3 D2 D1 D0 CHECKSUM

Resposta de 9 bytes:

5A CMD AH AL D3 D2 D1 D0 CHECKSUM

Comandos:

01 PING
02 VERSION
20 WRITE MEMORY
21 READ MEMORY

Endereços válidos:

0000 a 00FF

GOWIN
-----
1. Adicione os novos arquivos .v.
2. Ative apenas o .cst e o .sdc do HW006.
3. Defina o top module.
4. Limpe impl.
5. Execute Synthesize.
6. Execute Place & Route.
7. Grave o novo .fs com SRAM Program.

PYTHON
------
Teste padrão:

python dpdnano_input_memory_hw006.py --port COM15

Teste maior:

python dpdnano_input_memory_hw006.py --port COM15 --random 128

RESULTADO ESPERADO
------------------
RESULTADO: PASS - memória de entrada validada

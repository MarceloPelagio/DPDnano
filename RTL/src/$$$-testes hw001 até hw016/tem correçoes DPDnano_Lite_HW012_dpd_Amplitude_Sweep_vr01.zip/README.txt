DPDnano_Lite_v3_2
HW012_dpd - Amplitude Sweep AM/AM
=================================

OBJETIVO
--------
Caracterizar experimentalmente a curva de transferência AM/AM do
DPDnano-Lite implementado na Tang Nano 4K.

NÃO HÁ ALTERAÇÃO NO RTL
-----------------------
Reutilize exatamente o bitstream do HW010_dpd:

Top Module:
dpdnano_hw010_dpd_top

Coeficientes:
coef1 = 0x6000 + j0 = 0,75
coef3 = 0x1000 + j0 = 0,125

TESTE PADRÃO
------------
python dpdnano_hw012_dpd.py --port COM15

O teste padrão utiliza:

256 pontos
amplitude de 0 até 30000
entrada somente no eixo I
Q = 0

ARQUIVO CSV
-----------
O script gera:

hw012_dpd_amplitude_sweep.csv

Colunas:

index
input_i
input_q
input_magnitude
output_i
output_q
output_magnitude
gain
saturated
monotonic

OUTROS EXEMPLOS
---------------
128 pontos:

python dpdnano_hw012_dpd.py --port COM15 --points 128

Amplitude máxima diferente:

python dpdnano_hw012_dpd.py --port COM15 --max-amplitude 20000

Nome de CSV diferente:

python dpdnano_hw012_dpd.py --port COM15 --csv resultado_hw012.csv

GRÁFICO
-------
Depois do teste, execute:

python plot_hw012_dpd.py

Ou:

python plot_hw012_dpd.py --csv resultado_hw012.csv

Será gerado:

hw012_dpd_am_am.png

RESULTADO ESPERADO
------------------
RESULTADO: PASS - sweep de amplitude AM/AM validado

MÉTRICAS
--------
- quantidade de pontos;
- monotonicidade da curva;
- início da saturação;
- ocorrência de overflow;
- ganho em função da amplitude;
- arquivo CSV para uso no Capítulo 7 e Capítulo 8 do TCC.

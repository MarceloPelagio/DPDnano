#!/usr/bin/env python3
from __future__ import annotations

import argparse
import csv
from pathlib import Path

import matplotlib.pyplot as plt

parser = argparse.ArgumentParser(
    description=(
        "Gera gráfico AM/AM do HW012_dpd"
    )
)

parser.add_argument(
    "--csv",
    default="hw012_dpd_amplitude_sweep.csv",
)
parser.add_argument(
    "--output",
    default="hw012_dpd_am_am.png",
)

args = parser.parse_args()

input_magnitude = []
output_magnitude = []

with Path(args.csv).open(
    "r",
    encoding="utf-8",
) as csv_file:
    reader = csv.DictReader(csv_file)

    for row in reader:
        input_magnitude.append(
            float(row["input_magnitude"])
        )
        output_magnitude.append(
            float(row["output_magnitude"])
        )

plt.figure()
plt.plot(
    input_magnitude,
    output_magnitude,
)
plt.xlabel("Magnitude de entrada")
plt.ylabel("Magnitude de saída")
plt.title("HW012_dpd - Curva AM/AM")
plt.grid(True)
plt.tight_layout()
plt.savefig(
    args.output,
    dpi=200,
)
plt.show()

print(
    f"Gráfico salvo em: "
    f"{Path(args.output).resolve()}"
)

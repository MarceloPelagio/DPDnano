DPDnano_Lite_v3_2 - HW004 Structured Protocol

Coloque os arquivos dentro de:
src\dpdnano_hw_top

Reutilize do HW003:
uart_rx_27m_115200.v
uart_tx_27m_115200.v
dpdnano_hw003_uart_pingpong.cst
dpdnano_hw003_uart_pingpong.sdc

Top Module:
dpdnano_hw004_structured_protocol_top

Requisição:
A5 CMD DATA CHECKSUM

Resposta:
5A CMD STATUS/DATA CHECKSUM

Comandos:
01 PING -> 00
02 VERSION -> 32 hexadecimal, representando v3.2

Erros:
E1 comando desconhecido
E2 checksum inválido

Teste:
python dpdnano_protocol_hw004.py --port COM15

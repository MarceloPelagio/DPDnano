DPDnano_Lite_v3_2 - HW007 Output Memory

Coloque os arquivos em:
src\dpdnano_hw_top

Top Module:
dpdnano_hw007_output_memory_top

Reutilize:
uart_rx_27m_115200.v
uart_tx_27m_115200.v

Mantenha apenas uma cópia de cada módulo UART.

Memória:
256 x 32 bits
[31:16] = I
[15:0]  = Q

Comandos:
30 WRITE OUTPUT MEMORY
31 READ OUTPUT MEMORY

Teste:
python dpdnano_output_memory_hw007.py --port COM15

Teste maior:
python dpdnano_output_memory_hw007.py --port COM15 --random 128

Resultado esperado:
RESULTADO: PASS - memória de saída validada

DPDnano_Lite_v3_2 - HW008 Memory Transfer
===========================================

OBJETIVO
--------
Validar o fluxo completo entre as duas memórias:

Input Memory
    ->
Controlador de processamento
    ->
Output Memory

Neste teste, o processamento é uma cópia determinística:

OUT[n] = IN[n]

Isso valida:
- duas BSRAMs simultâneas;
- leitura síncrona;
- controlador de endereços;
- contador de palavras;
- BUSY;
- DONE;
- escrita automática na memória de saída.

LOCAL DOS ARQUIVOS
------------------
Os arquivos podem ficar diretamente em:

src

TOP MODULE
----------
dpdnano_hw008_memory_transfer_top

REUTILIZAR
----------
Mantenha apenas uma cópia de:

uart_rx_27m_115200.v
uart_tx_27m_115200.v

PROTOCOLO
---------
20 WRITE INPUT MEMORY
21 READ INPUT MEMORY
31 READ OUTPUT MEMORY
40 PROCESS/COPY

No comando PROCESS:
- endereço = início do bloco;
- data[15:0] = quantidade;
- quantidade zero representa 256 palavras.

TESTE
-----
Teste padrão com 64 palavras:

python dpdnano_memory_transfer_hw008.py --port COM15

Teste completo de 256 palavras:

python dpdnano_memory_transfer_hw008.py --port COM15 --count 256

Teste parcial:

python dpdnano_memory_transfer_hw008.py --port COM15 --start 32 --count 100

RESULTADO ESPERADO
------------------
RESULTADO: PASS - transferência Input -> Output validada

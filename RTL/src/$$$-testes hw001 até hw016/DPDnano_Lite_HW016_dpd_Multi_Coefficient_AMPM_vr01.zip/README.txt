DPDnano_Lite_v3_2
HW016_dpd - Comparação AM/PM com múltiplos coeficientes
========================================================

PERFIS
-------
A: coef1=0,40+j0; coef3=0+j0,00  (azul)
B: coef1=0,40+j0; coef3=0+j0,10  (verde)
C: coef1=0,40+j0; coef3=0+j0,20  (vermelho)
D: coef1=0,40+j0; coef3=0+j0,35  (preto)

IMPORTANTE
----------
Cada perfil deve ser sintetizado separadamente para permitir que o Gowin
faça poda de coeficientes constantes e mantenha o uso de DSP <= 4.

PROCEDIMENTO PARA CADA PERFIL
-----------------------------
1. Abra hw016_profiles.vh.
2. Deixe apenas um `define HW016_PROFILE_X ativo.
3. Defina o top: dpdnano_hw016_dpd_top.
4. Clean impl, Synthesize, confira DSP <= 4, Place & Route e SRAM Program.
5. Execute, por exemplo para o Perfil A:
   python dpdnano_hw016_dpd.py --port COM15 --profile A
6. Repita para B, C e D.

ARQUIVOS GERADOS
-----------------
hw016_profile_A.csv
hw016_profile_B.csv
hw016_profile_C.csv
hw016_profile_D.csv

GRÁFICO FINAL
-------------
python plot_hw016_dpd_compare.py

Saída:
hw016_dpd_ampm_comparison.png

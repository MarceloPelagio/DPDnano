#!/usr/bin/env python3
import csv
from pathlib import Path
import matplotlib.pyplot as plt

profiles=[
 ("A","Linear: coef3_im=0,00","blue"),
 ("B","AM/PM leve: coef3_im=0,10","green"),
 ("C","AM/PM média: coef3_im=0,20","red"),
 ("D","AM/PM forte: coef3_im=0,35","black"),
]

plt.figure(figsize=(10,6.5))
for profile,label,color in profiles:
    path=Path(f"hw016_profile_{profile}.csv")
    if not path.exists():
        raise FileNotFoundError(f"Arquivo ausente: {path}")
    x=[]; y=[]
    with path.open("r",encoding="utf-8") as f:
        for row in csv.DictReader(f):
            x.append(float(row["input_magnitude"]))
            y.append(float(row["phase_shift_deg"]))
    plt.plot(x,y,color=color,linewidth=2.2,label=label)

plt.axhline(0,color="magenta",linestyle="--",linewidth=1.4,label="Referência sem rotação")
plt.xlabel("Magnitude de entrada (Q1.15)")
plt.ylabel("Desvio de fase AM/PM (graus)")
plt.title("DPDnano-Lite HW016_dpd - Comparação AM/PM por coeficientes\ncoef1 = 0x3333 + j0x0000; coef3_re = 0x0000")
plt.grid(True,linestyle="--",alpha=0.35)
plt.legend(loc="best")
plt.tight_layout()
plt.savefig("hw016_dpd_ampm_comparison.png",dpi=300)
plt.show()
print(f"Gráfico salvo em: {Path('hw016_dpd_ampm_comparison.png').resolve()}")

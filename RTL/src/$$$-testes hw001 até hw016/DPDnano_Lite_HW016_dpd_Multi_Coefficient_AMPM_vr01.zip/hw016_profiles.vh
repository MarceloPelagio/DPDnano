/* HW016_dpd - habilite EXATAMENTE um perfil */
`define HW016_PROFILE_A
//`define HW016_PROFILE_B
//`define HW016_PROFILE_C
//`define HW016_PROFILE_D

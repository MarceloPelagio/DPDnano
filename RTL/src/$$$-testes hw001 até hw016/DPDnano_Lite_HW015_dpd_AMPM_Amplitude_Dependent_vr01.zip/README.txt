DPDnano_Lite_v3_2
HW015_dpd - AM/PM dependente da amplitude
=========================================

Coeficientes:
coef1 = 0x3333 + j0x0000 ≈ 0,40 + j0,00
coef3 = 0x0000 + j0x2CCD ≈ 0,00 + j0,35

O coeficiente cúbico imaginário produz rotação de fase crescente
com a amplitude.

Top Module:
dpdnano_hw015_dpd_top

Reutilizar:
protocol_controller_hw009_dpd.v
input_memory_dualread_256x32.v
output_memory_dualport_256x32.v
uart_rx_27m_115200.v
uart_tx_27m_115200.v
módulos rtl_v3_1 usados pelo dpd_core

Procedimento:
1. Selecione otimização Auto/Balanced, não DSP only.
2. Clean impl.
3. Synthesize.
4. Confirme uso de DSP <= 4.
5. Place & Route.
6. SRAM Program.

Teste:
python dpdnano_hw015_dpd.py --port COM15

Gráfico:
python plot_hw015_dpd.py

Resultado esperado:
RESULTADO: PASS - AM/PM dependente da amplitude validada

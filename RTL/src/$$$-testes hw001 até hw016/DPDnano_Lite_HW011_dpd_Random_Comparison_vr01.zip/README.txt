DPDnano_Lite_v3_2
HW011_dpd - Random FPGA x Python Comparison
================================================

OBJETIVO
--------
Ampliar a validação do HW010_dpd para até 256 vetores I/Q,
comparando a saída da FPGA com o modelo Python de referência.

NÃO HÁ ALTERAÇÃO NO RTL
-----------------------
Este teste reutiliza exatamente o bitstream do HW010_dpd:

Top Module:
dpdnano_hw010_dpd_top

Coeficientes:
coef1 = 0x6000 + j0 = 0,75
coef3 = 0x1000 + j0 = 0,125

Portanto, não é necessário sintetizar novamente.

TESTE PADRÃO
------------
python dpdnano_hw011_dpd.py --port COM15

O teste padrão utiliza:

256 vetores
amplitude máxima = ±12000
seed = 11011
tolerância = 1 LSB

EXIBIR TODAS AS AMOSTRAS
------------------------
python dpdnano_hw011_dpd.py --port COM15 --show-all

OUTROS EXEMPLOS
---------------
128 vetores:

python dpdnano_hw011_dpd.py --port COM15 --count 128

Outra seed:

python dpdnano_hw011_dpd.py --port COM15 --seed 12345

Amplitude diferente:

python dpdnano_hw011_dpd.py --port COM15 --amplitude 10000

Tolerância zero, para medir coincidência bit a bit estrita:

python dpdnano_hw011_dpd.py --port COM15 --tolerance 0

MÉTRICAS APRESENTADAS
---------------------
- quantidade de amostras;
- componentes I/Q avaliados;
- quantidade de pares I/Q com coincidência exata;
- erro absoluto máximo;
- erro absoluto médio;
- distribuição dos erros em LSB;
- indicação de overflow;
- quantidade de amostras fora da tolerância.

RESULTADO ESPERADO
------------------
RESULTADO: PASS - comparação aleatória FPGA x Python validada

OBSERVAÇÃO
----------
A tolerância padrão foi reduzida de 4 LSB no HW010_dpd para 1 LSB
neste HW011_dpd, pois o teste anterior mostrou erro máximo observado
de apenas ±1 LSB.

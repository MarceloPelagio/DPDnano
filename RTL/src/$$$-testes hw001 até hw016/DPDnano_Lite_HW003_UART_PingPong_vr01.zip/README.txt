DPDnano_Lite_v3_2 - HW003 UART PING/PONG

Use os módulos uart_rx_27m_115200.v e uart_tx_27m_115200.v já validados no HW002.

Top Module:
dpdnano_hw003_uart_pingpong_top

Comando:
PC envia 0x50 ('P')
FPGA responde 0x4B ('K')

LEDs ativos em nível baixo:
41 BUSY
42 DONE
43 ERROR

Teste:
python dpdnano_uart_pingpong_hw003.py --port COM15

Teste longo:
python dpdnano_uart_pingpong_hw003.py --port COM15 --repeat 1000

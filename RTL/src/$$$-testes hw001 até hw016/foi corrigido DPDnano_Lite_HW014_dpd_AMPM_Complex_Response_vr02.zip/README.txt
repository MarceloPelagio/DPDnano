DPDnano_Lite_v3_2
HW014_dpd vr02 - Correção do limite de DSP
===========================================

PROBLEMA DA VR01
----------------
A configuração:

coef1 = 0,40 + j0,05
coef3 = 0,55 + j0,20

inferiu 5 DSPs, ultrapassando o limite de 4 DSPs informado pela
ferramenta para o dispositivo selecionado.

CORREÇÃO
--------
A vr02 utiliza:

coef1 = 0x3333 + j0x0000 ≈ 0,40 + j0,00
coef3 = 0x4666 + j0x199A ≈ 0,55 + j0,20

A parte imaginária cúbica permanece ativa, portanto a rotação de fase
continua dependente da amplitude e o ensaio AM/PM permanece válido.

SUBSTITUIR
----------
Substitua somente:

dpd_controller_hw014_dpd.v

Mantenha o mesmo top e os demais arquivos da vr01.

Também atualize nos scripts e gráficos qualquer texto:

coef1 = 0x3333 + j0x0666

para:

coef1 = 0x3333 + j0x0000

Depois:
1. Clean impl
2. Synthesize
3. Verifique que o uso caiu para no máximo 4 DSPs
4. Place & Route
5. SRAM Program
6. Execute o teste HW014_dpd

DPDnano_Lite_v3_2 - HW009_dpd

Primeira integração funcional:
Input Memory -> dpd_controller -> dpd_core -> Output Memory

Clock único nesta etapa: 27 MHz.
Coeficientes:
linear = 0x7FFF + j0
cúbico = 0

Coloque os arquivos temporários em src.

Top Module:
dpdnano_hw009_dpd_top

Reutilize somente uma cópia de:
uart_rx_27m_115200.v
uart_tx_27m_115200.v

Mantenha no projeto todos os módulos de rtl_v3_1 necessários ao dpd_core.

Ative somente:
dpdnano_hw009_dpd.cst
dpdnano_hw009_dpd.sdc

Depois:
1. Limpe impl.
2. Synthesize.
3. Place & Route.
4. SRAM Program.
5. Execute:
   python dpdnano_hw009_dpd.py --port COM15

A saída deve acompanhar a entrada com tolerância padrão de 3 LSB.

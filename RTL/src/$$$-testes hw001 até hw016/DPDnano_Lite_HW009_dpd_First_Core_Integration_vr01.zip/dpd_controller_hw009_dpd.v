`timescale 1ns/1ps
`include "config.vh"
module dpd_controller_hw009_dpd(
 input wire clk,input wire rst,input wire start_i,
 input wire [7:0] start_addr_i,input wire [8:0] count_i,
 output reg in_mem_rd_en_o,output reg [7:0] in_mem_rd_addr_o,
 input wire [31:0] in_mem_rd_data_i,input wire in_mem_rd_valid_i,
 output reg out_mem_wr_en_o,output reg [7:0] out_mem_wr_addr_o,
 output reg [31:0] out_mem_wr_data_o,output reg busy_o,
 output reg done_o,output reg error_o,output reg overflow_seen_o);

localparam IDLE=0,READ=1,FEED=2,WAIT_DPD=3,WRITE=4,FINISH=5;
reg [2:0] state;
reg [7:0] current_addr;
reg [8:0] remaining;
reg dpd_in_valid;
reg signed [`DATA_WIDTH-1:0] dpd_din_re,dpd_din_im;
wire dpd_out_valid;
wire signed [`DATA_WIDTH-1:0] dpd_dout_re,dpd_dout_im;
wire dpd_overflow,dpd_overflow_re,dpd_overflow_im;

localparam signed [`COEF_WIDTH-1:0] COEF1_RE=16'sd32767;
localparam signed [`COEF_WIDTH-1:0] COEF1_IM=16'sd0;
localparam signed [`COEF_WIDTH-1:0] COEF3_RE=16'sd0;
localparam signed [`COEF_WIDTH-1:0] COEF3_IM=16'sd0;

dpd_core u_core(
 .clk(clk),.rst(rst),.in_valid(dpd_in_valid),
 .din_re(dpd_din_re),.din_im(dpd_din_im),
 .coef1_re(COEF1_RE),.coef1_im(COEF1_IM),
 .coef3_re(COEF3_RE),.coef3_im(COEF3_IM),
`ifdef DPD_ENABLE_OVERFLOW_FLAGS
 .overflow(dpd_overflow),.overflow_re(dpd_overflow_re),
 .overflow_im(dpd_overflow_im),
`endif
 .out_valid(dpd_out_valid),.dout_re(dpd_dout_re),.dout_im(dpd_dout_im));

`ifndef DPD_ENABLE_OVERFLOW_FLAGS
assign dpd_overflow=1'b0;
assign dpd_overflow_re=1'b0;
assign dpd_overflow_im=1'b0;
`endif

always @(posedge clk or posedge rst) begin
 if(rst) begin
  state<=IDLE; current_addr<=0; remaining<=0;
  in_mem_rd_en_o<=0; in_mem_rd_addr_o<=0;
  out_mem_wr_en_o<=0; out_mem_wr_addr_o<=0; out_mem_wr_data_o<=0;
  dpd_in_valid<=0; dpd_din_re<=0; dpd_din_im<=0;
  busy_o<=0; done_o<=0; error_o<=0; overflow_seen_o<=0;
 end else begin
  in_mem_rd_en_o<=0; out_mem_wr_en_o<=0; dpd_in_valid<=0; done_o<=0;
  if(dpd_overflow|dpd_overflow_re|dpd_overflow_im) overflow_seen_o<=1;
  case(state)
   IDLE: begin
    busy_o<=0;
    if(start_i) begin
     if(count_i==0) error_o<=1;
     else begin
      error_o<=0; overflow_seen_o<=0; current_addr<=start_addr_i;
      remaining<=count_i; busy_o<=1;
      in_mem_rd_addr_o<=start_addr_i; in_mem_rd_en_o<=1; state<=READ;
     end
    end
   end
   READ: if(in_mem_rd_valid_i) begin
    dpd_din_re<=in_mem_rd_data_i[31:16];
    dpd_din_im<=in_mem_rd_data_i[15:0];
    state<=FEED;
   end
   FEED: begin dpd_in_valid<=1; state<=WAIT_DPD; end
   WAIT_DPD: if(dpd_out_valid) begin
    out_mem_wr_addr_o<=current_addr;
    out_mem_wr_data_o<={dpd_dout_re,dpd_dout_im};
    state<=WRITE;
   end
   WRITE: begin
    out_mem_wr_en_o<=1;
    if(remaining==1) state<=FINISH;
    else begin
     current_addr<=current_addr+1'b1;
     remaining<=remaining-1'b1;
     in_mem_rd_addr_o<=current_addr+1'b1;
     in_mem_rd_en_o<=1;
     state<=READ;
    end
   end
   FINISH: begin busy_o<=0; done_o<=1; state<=IDLE; end
   default: state<=IDLE;
  endcase
 end
end
endmodule

DPDnano_Lite_v3_2 - HW005 Register Bank

Coloque todos os arquivos dentro de:
src\dpdnano_hw_top

Top Module:
dpdnano_hw005_register_bank_top

Protocolo de 5 bytes:
Requisição:
A5 CMD ADDR DATA CHECKSUM

Resposta:
5A CMD ADDR STATUS/DATA CHECKSUM

Comandos:
01 PING
02 VERSION
10 WRITE REGISTER
11 READ REGISTER

Banco:
8 registradores de 8 bits
Endereços 00 a 07

Teste:
python dpdnano_register_bank_hw005.py --port COM15

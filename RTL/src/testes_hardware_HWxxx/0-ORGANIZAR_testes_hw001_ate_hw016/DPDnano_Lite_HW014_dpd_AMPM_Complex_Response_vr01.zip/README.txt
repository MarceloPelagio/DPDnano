DPDnano_Lite_v3_2
HW014_dpd - AM/PM e Resposta Complexa
=====================================

OBJETIVO
--------
Validar em hardware:

- processamento completo das componentes I e Q;
- rotação de fase controlada;
- característica AM/PM dependente da amplitude;
- invariância da resposta entre os diferentes quadrantes;
- ausência de overflow no intervalo testado.

COEFICIENTES COMPLEXOS
----------------------
coef1 = 0x3333 + j0x0666
      ≈ 0,40 + j0,05

coef3 = 0x4666 + j0x199A
      ≈ 0,55 + j0,20

Os termos imaginários são intencionais e produzem rotação de fase.

ARQUIVOS NOVOS
--------------
dpdnano_hw014_dpd_top.v
dpd_controller_hw014_dpd.v
dpdnano_hw014_dpd.py
plot_hw014_dpd_ampm.py
plot_hw014_dpd_iq.py
dpdnano_hw014_dpd.cst
dpdnano_hw014_dpd.sdc

REUTILIZAR
----------
protocol_controller_hw009_dpd.v
input_memory_dualread_256x32.v
output_memory_dualport_256x32.v
uart_rx_27m_115200.v
uart_tx_27m_115200.v
módulos congelados de rtl_v3_1

TOP MODULE
----------
dpdnano_hw014_dpd_top

SÍNTESE
-------
Os coeficientes foram alterados. É necessário:

1. Clean impl
2. Synthesize
3. Place & Route
4. SRAM Program

TESTE
-----
python dpdnano_hw014_dpd.py --port COM15

O teste padrão usa:

32 amplitudes
8 fases por amplitude
256 vetores complexos
amplitude máxima 28000

GRÁFICO AM/PM
-------------
python plot_hw014_dpd_ampm.py

Arquivo:

hw014_dpd_am_pm.png

GRÁFICO DO PLANO I/Q
--------------------
python plot_hw014_dpd_iq.py

Arquivo:

hw014_dpd_iq_plane.png

RESULTADO ESPERADO
------------------
RESULTADO: PASS - resposta complexa e AM/PM validadas

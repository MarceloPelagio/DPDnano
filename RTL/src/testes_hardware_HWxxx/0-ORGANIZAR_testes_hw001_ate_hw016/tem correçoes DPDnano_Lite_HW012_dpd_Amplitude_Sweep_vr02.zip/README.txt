DPDnano_Lite_v3_2 - HW012_dpd vr02

Nova repetição do sweep AM/AM com curvatura mais pronunciada.

Coeficientes:
coef1 = 0x599A = aproximadamente 0,70
coef3 = 0x2666 = aproximadamente 0,30

Top Module:
dpdnano_hw012_dpd_top

Reutilizar:
protocol_controller_hw009_dpd.v
input_memory_dualread_256x32.v
output_memory_dualport_256x32.v
uart_rx_27m_115200.v
uart_tx_27m_115200.v
módulos rtl_v3_1 do dpd_core

Sintetizar novamente, pois os coeficientes do RTL foram alterados.

Teste:
python dpdnano_hw012_dpd_vr02.py --port COM15

Gráfico:
python plot_hw012_dpd_vr02.py

Arquivos gerados:
hw012_dpd_amplitude_sweep_vr02.csv
hw012_dpd_am_am_vr02.png
